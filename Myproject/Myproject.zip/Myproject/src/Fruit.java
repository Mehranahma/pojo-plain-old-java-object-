public class Fruit {
    private String name , colour;

    public void setName(String n)
    {
        name = n;
    }
    public void setColour(String c)
    {
        colour = c;
    }

    public String getName()
    {
        return  name;
    }
    public String getColour() {
        return colour;
    }
}
